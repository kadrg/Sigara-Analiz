package com.sigarasayaci.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Sigara Sayacı: arayüz assets/index.html içinde; kayıtlar telefondaki
 * uygulama klasöründe sigara.json dosyasında tutulur (tarayıcı depolaması kullanılmaz).
 */
public class MainActivity extends Activity {

    private static final String DATA_FILE = "sigara.json";
    private static final int REQ_EXPORT = 41;
    private static final int REQ_IMPORT = 42;

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        colorSystemBars();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);          // tarayıcı depolaması kapalı
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);           // uygulama çevrimdışı çalışır
        s.setTextZoom(100);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setBackgroundColor(isNight() ? Color.parseColor("#121915") : Color.parseColor("#EEF2EC"));
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return true;                     // uygulama dışına gezinme yok
            }
        });
        web.addJavascriptInterface(new Store(), "AndroidStore");
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private void colorSystemBars() {
        Window w = getWindow();
        boolean night = isNight() && Build.VERSION.SDK_INT >= 29;
        int bg = night ? Color.parseColor("#121915") : Color.parseColor("#EEF2EC");
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        int flags = 0;
        if (!night) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        colorSystemBars();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("window.appBack?window.appBack():false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.dispatchEvent(new Event('focus'))", null);
    }

    // ---------- dosya işlemleri ----------

    private synchronized String readData() {
        File f = new File(getFilesDir(), DATA_FILE);
        if (!f.exists()) return null;
        try (InputStream in = new FileInputStream(f)) {
            return new String(readAll(in), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    /** Önce geçici dosyaya yazar, sonra yerine taşır: yazma yarıda kalırsa eski veri bozulmaz. */
    private synchronized boolean writeData(String json) {
        File dir = getFilesDir();
        File tmp = new File(dir, DATA_FILE + ".tmp");
        File dst = new File(dir, DATA_FILE);
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } catch (Exception e) {
            return false;
        }
        return tmp.renameTo(dst);
    }

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) {
            boolean ok = false;
            String json = readData();
            if (json != null) {
                try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                    if (out != null) {
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                        ok = true;
                    }
                } catch (Exception ignored) { }
            }
            web.evaluateJavascript("window.onDataExported&&window.onDataExported(" + ok + ")", null);
        } else if (requestCode == REQ_IMPORT) {
            boolean ok = false;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in != null) {
                    String json = new String(readAll(in), StandardCharsets.UTF_8);
                    JSONObject o = new JSONObject(json);   // geçerli bir yedek mi?
                    if (o.has("days")) ok = writeData(json);
                }
            } catch (Exception ignored) { }
            web.evaluateJavascript(ok
                    ? "window.onDataImported&&window.onDataImported()"
                    : "window.onDataExported&&window.onDataExported(false)", null);
        }
    }

    // ---------- JavaScript köprüsü ----------

    private class Store {
        @JavascriptInterface
        public String load() {
            return readData();
        }

        @JavascriptInterface
        public boolean save(String json) {
            return writeData(json);
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v == null) return;
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        }

        @JavascriptInterface
        public void exportData() {
            runOnUiThread(() -> {
                String stamp = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, "sigara-sayaci-yedek-" + stamp + ".json");
                startActivityForResult(i, REQ_EXPORT);
            });
        }

        @JavascriptInterface
        public void importData() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, REQ_IMPORT);
            });
        }
    }
}
