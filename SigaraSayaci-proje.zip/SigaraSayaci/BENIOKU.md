# Sigara Sayacı (Android)

Günlük sigara hedefinden geri sayan, her sigaranın tarih ve saatini kaydeden ve istatistik çıkaran Android uygulaması.

- Veriler telefonda, uygulamanın kendi klasöründe `sigara.json` dosyasında saklanır. İnternet izni yoktur.
- Gün sabah 05:00'te başlar (ayarlanabilir). Gece yarısından sonra içilenler önceki güne sayılır.
- İki sigara arası süre yalnızca aynı gün içinde ölçülür; uyku arası ortalamaya girmez.
- "Yedek dosyası oluştur" ile kayıtlar bir JSON dosyasına alınabilir ve geri yüklenebilir.

## APK nasıl oluşturulur

### Yol 1: GitHub (bilgisayara program kurmadan)
1. github.com'da yeni, boş bir depo açın.
2. Bu klasördeki tüm dosyaları (gizli `.github` klasörü dahil) depoya yükleyin.
3. Depoda **Actions** sekmesine girin; "APK oluştur" işi kendiliğinden başlar (yaklaşık 3–5 dakika).
4. İş bitince sayfanın altındaki **Artifacts** bölümünden `SigaraSayaci-apk` dosyasını indirin, zip'i açın: içinde `app-debug.apk` var.

### Yol 2: Android Studio
1. Android Studio'da **File → Open** ile bu klasörü açın.
2. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Telefona kurulum
APK'yı telefona atın ve dokunun. Android "bilinmeyen kaynaklardan yükleme" izni isterse o uygulama (Dosyalar, Chrome vb.) için izin verin.
Play Protect uyarı gösterirse "Yine de yükle"yi seçin; uygulama Play Store dışından geldiği için bu uyarı normaldir.
